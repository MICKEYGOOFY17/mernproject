import React from 'react';
import ReactDOM from 'react-dom';
import Child from './components/sample';

class MainComponent extends React.Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                <h1>React App</h1>
                <h2>Hello from React</h2>
                <Child/>
            </div>
        )
    }
}
ReactDOM.render(
    <MainComponent/>, document.getElementById('mountapp'));
