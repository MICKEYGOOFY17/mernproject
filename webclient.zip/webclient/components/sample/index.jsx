import React from 'react';
import ReactDOM from 'react-dom';
import Child from './childComponent.jsx';
import Child1 from './childComponent1.jsx';

class ParentComponent extends React.Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
              <Child/>
              <Child1/>
            </div>
        )
    }
}

export default ParentComponent;
