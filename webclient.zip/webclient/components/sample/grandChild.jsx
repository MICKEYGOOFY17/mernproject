import React from 'react';
import ReactDOM from 'react-dom';

export class GrandChild extends React.Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                <h2>Hello from Grand Child </h2>
            </div>
        )
    }
}
